<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<g>
		<g>
			<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M31,1c-0.667,0-1.333,0.022-1.998,0.066"/>
			<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4.1705,2.0853" d="M26.929,1.275
				C20.659,2.13,14.607,4.967,9.788,9.787C-0.91,20.484-1.841,37.248,6.997,49l3.846,3.847"/>
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="11.584" y1="53.588" x2="12.998" y2="55.002"/>
		</g>
	</g>
</g>
<g>
	<g>
		<g>
			<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M33,63c0.667,0,1.333-0.022,1.998-0.066"/>
			<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4.1705,2.0853" d="M37.071,62.725
				c6.27-0.854,12.321-3.691,17.141-8.512C64.91,43.516,65.841,26.752,57.003,15l-3.846-3.847"/>
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="52.416" y1="10.412" x2="51.002" y2="8.998"/>
		</g>
	</g>
</g>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="13,44 13,55 2,55 
	"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="51,20 51,9 62,9 
	"/>
</svg>
