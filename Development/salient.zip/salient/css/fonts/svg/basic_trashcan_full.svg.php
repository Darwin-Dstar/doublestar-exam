<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="52,36 58,34 62,48 56,50 	"/>
	<rect x="10" y="13" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="36" height="50"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="22" x2="22" y2="56"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="34" y1="22" x2="34" y2="56"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="47.926" y1="21.895" x2="60" y2="63"/>
</g>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="12,13 14,6 22.857,6.143 25,13 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="22.857,6.143 27,1 39,1 44,13 "/>
</svg>
