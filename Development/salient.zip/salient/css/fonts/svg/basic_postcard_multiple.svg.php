<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<rect x="1" y="20" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="53" height="34"/>
</g>
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="10,16.999 10,11 63,11 63,45 57,45 	"/>
</g>
<rect x="42" y="25" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="7" height="8"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="33" y1="24" x2="33" y2="50"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="5" y1="27" x2="29" y2="27"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="5" y1="32" x2="26" y2="32"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="5" y1="37" x2="27" y2="37"/>
</svg>
